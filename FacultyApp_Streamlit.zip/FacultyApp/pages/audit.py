"""pages/audit.py — Audit Merge page"""

import io, pandas as pd, streamlit as st
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

NAVY="1B3A6B"; TEAL="0E7C7B"; WHITE="FFFFFF"
LIGHT="EEF2FA"; GOLD="F5A623"; DARK="2C3E50"
SUP_HDR="0A5C52"; SUP_VAL="D4F0EA"; SUP_EMPTY="F5FFFE"


def load_supervision(file):
    df = pd.read_excel(file, header=0)
    df.columns = [str(c).replace("\n"," ").strip() for c in df.columns]
    df = df[df["Name"].notna()].copy()
    df["Name"]       = df["Name"].astype(str).str.strip()
    df["Faculty ID"] = pd.to_numeric(df["Faculty ID"], errors="coerce")
    df["Workload Assignment"] = pd.to_numeric(df["Workload Assignment"], errors="coerce").fillna(0)
    type_col = next((c for c in df.columns if "type" in c.lower() and
                     any(k in c for k in ["LEC","LAB","INT","Type"])), None)
    if type_col is None:
        raise ValueError("Cannot find Class Type column in supervision file.")
    agg = df.groupby(["Faculty ID", type_col])["Workload Assignment"].sum().unstack(fill_value=0).reset_index()
    for col in ["Capstone","UG_Internship","Thesis"]:
        if col not in agg.columns: agg[col] = 0
    agg["Total Supervision WL"] = agg["Capstone"]+agg["UG_Internship"]+agg["Thesis"]
    best = (df.groupby("Faculty ID")["Name"]
              .apply(lambda g: max((n for n in g if not str(n).isupper()),
                                   default=max(g, key=len), key=len))
              .reset_index())
    best.columns = ["Faculty ID","Display Name"]
    agg = agg.merge(best, on="Faculty ID", how="left")
    for col in ["Capstone","UG_Internship","Thesis","Total Supervision WL"]:
        agg[col] = agg[col].round(4)
    return agg.set_index("Faculty ID")


def load_audit(file, sheet_name=None):
    xl = pd.ExcelFile(file)
    if sheet_name and sheet_name in xl.sheet_names:
        target = sheet_name
    else:
        preferred = [s for s in xl.sheet_names if "payment" in s.lower() and "(2)" in s]
        if not preferred:
            preferred = [s for s in xl.sheet_names if "payment" in s.lower()]
        target = preferred[0] if preferred else xl.sheet_names[0]
    raw = pd.read_excel(file, sheet_name=target, header=None)
    header_row = None
    for i, row in raw.iterrows():
        vals = [str(v).replace("\n"," ").strip() for v in row.values if pd.notna(v)]
        if "Faculty Name" in vals:
            header_row = i; break
    if header_row is None:
        raise ValueError(f"Cannot find 'Faculty Name' header in sheet '{target}'")
    df = pd.read_excel(file, sheet_name=target, header=header_row)
    df.columns = [str(c).replace("\n"," ").strip() for c in df.columns]
    df = df[df["Faculty Name"].notna()].copy()
    df["Faculty ID"] = pd.to_numeric(df["Faculty ID"], errors="coerce")
    return df, target


def merge(audit_df, sup_df):
    seen = set()
    cap_v,int_v,th_v,tot_v,matched = [],[],[],[],[]
    for _,row in audit_df.iterrows():
        fid = row.get("Faculty ID")
        if pd.notna(fid) and int(fid) in sup_df.index and int(fid) not in seen:
            s = sup_df.loc[int(fid)]
            cap_v.append(round(float(s["Capstone"]),4))
            int_v.append(round(float(s["UG_Internship"]),4))
            th_v.append(round(float(s["Thesis"]),4))
            tot_v.append(round(float(s["Total Supervision WL"]),4))
            matched.append(True); seen.add(int(fid))
        else:
            cap_v.append(None); int_v.append(None)
            th_v.append(None);  tot_v.append(None); matched.append(False)
    df = audit_df.copy()
    df["_Cap"]=cap_v; df["_Int"]=int_v
    df["_Th"]=th_v;   df["_Tot"]=tot_v; df["_matched"]=matched
    return df


def build_excel(merged_df, source_name=""):
    orig = [c for c in merged_df.columns if not c.startswith("_")]
    fn_idx = next((i for i,c in enumerate(orig) if c=="Faculty Name"), 0)
    SUP = [("Capstone\nWL","_Cap"),("UG Internship\nWL","_Int"),
           ("Thesis\nWL","_Th"),("Total\nSupervision WL","_Tot")]
    col_order = ([(c,None) for c in orig[:fn_idx+1]]
                 +[(lbl,key) for lbl,key in SUP]
                 +[(c,None) for c in orig[fn_idx+1:]])
    n = len(col_order)
    CW = {"Sl No.":5,"Faculty Name":28,"Faculty ID":11,"Position (FT/PT)":10,
          "Semester (Fall/Win/ SP/SU)":9,"Campus":7,"Career (UG/PG)":8,
          "Course Code":11,"Course Credit":8,"Workload Assignment":10,
          "Load per Semester":9,"Total Actual Workload per Faculty":9,
          "Regular Load":8,"Overload":8,"Total Overload in AED":11,
          "Capstone\nWL":10,"UG Internship\nWL":11,"Thesis\nWL":9,"Total\nSupervision WL":12}

    def H(ws,r,c,v,bg=NAVY,fg=WHITE,bold=True,sz=9,ha="center",wrap=True):
        cell=ws.cell(row=r,column=c,value=v)
        cell.font=Font(name="Arial",bold=bold,color=fg,size=sz)
        cell.fill=PatternFill("solid",fgColor=bg)
        cell.alignment=Alignment(horizontal=ha,vertical="center",wrap_text=wrap)
        return cell

    wb=Workbook(); ws=wb.active; ws.title="Merged Audit"
    ws.sheet_view.showGridLines=False; ws.row_dimensions[1].height=6

    title=("COE Faculty Workload — Audit + Supervision Merged"
           +(f"  ({source_name})" if source_name else ""))
    ws.merge_cells(f"A2:{get_column_letter(n)}2")
    H(ws,2,1,title,sz=12); ws.row_dimensions[2].height=28
    ws.merge_cells(f"A3:{get_column_letter(n)}3")
    H(ws,3,1,"  Blue-green columns = supervision workload (Capstone/Internship/Thesis)  |  Values on first row of each faculty only",
      bg=TEAL,sz=9,ha="left"); ws.row_dimensions[3].height=16
    ws.row_dimensions[4].height=6

    for j,(lbl,key) in enumerate(col_order,1):
        ws.column_dimensions[get_column_letter(j)].width=CW.get(lbl,10)
        is_s=(key is not None)
        c=ws.cell(row=5,column=j,value=lbl.replace("\\n","\n"))
        c.font=Font(name="Arial",bold=True,color=WHITE,size=8)
        c.fill=PatternFill("solid",fgColor=SUP_HDR if is_s else NAVY)
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        c.border=Border(bottom=Side(style="medium",color="00E5CC" if is_s else GOLD))
    ws.row_dimensions[5].height=28

    prev=None
    for _,row in merged_df.iterrows():
        fid=row.get("Faculty ID"); is_first=(fid!=prev); prev=fid
        r=ws.max_row+1; bg=LIGHT if (r%2==0) else "FFFFFF"
        for j,(lbl,key) in enumerate(col_order,1):
            cell=ws.cell(row=r,column=j); is_s=(key is not None)
            if is_s:
                val=row.get(key) if is_first else None
                if val is not None and isinstance(val,float):
                    cell.value=round(val,4); cell.number_format="0.000"
                    cell.font=Font(name="Arial",bold=True,color=DARK,size=9)
                    cell.fill=PatternFill("solid",fgColor=SUP_VAL)
                else:
                    cell.fill=PatternFill("solid",fgColor=SUP_EMPTY)
                cell.alignment=Alignment(horizontal="center",vertical="center")
            else:
                raw=row.get(lbl)
                cell.value=str(raw).strip() if pd.notna(raw) else None
                cell.font=Font(name="Arial",size=9,
                               bold=(is_first and lbl=="Faculty Name"))
                cell.fill=PatternFill("solid",fgColor="E8F0FF" if is_first and lbl=="Faculty Name" else bg)
                cell.alignment=Alignment(horizontal="left" if lbl in("Faculty Name","Comments (load reduction, others)") else "center",
                                         vertical="center")
        ws.row_dimensions[r].height=15
    ws.freeze_panes="A6"

    # Supervision summary
    ws2=wb.create_sheet("Supervision Summary"); ws2.sheet_view.showGridLines=False
    ws2.row_dimensions[1].height=6
    ws2.merge_cells("A2:H2")
    H(ws2,2,1,"SUPERVISION WORKLOAD SUMMARY",sz=13); ws2.row_dimensions[2].height=26
    sh=["#","Faculty Name","Faculty ID","Capstone WL","UG Internship WL","Thesis WL","Total Supervision WL","In Audit?"]
    sw=[4,36,12,14,16,12,18,10]
    for j,(h,w) in enumerate(zip(sh,sw),1):
        ws2.column_dimensions[get_column_letter(j)].width=w
        c=ws2.cell(row=3,column=j,value=h)
        c.font=Font(name="Arial",bold=True,size=9,color=WHITE)
        c.fill=PatternFill("solid",fgColor=SUP_HDR)
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
    ws2.row_dimensions[3].height=22
    audit_ids=set(merged_df["Faculty ID"].dropna().astype(int).unique())
    sub=merged_df[merged_df["_matched"]==True].drop_duplicates("Faculty ID").sort_values("_Tot",ascending=False)
    for i,row in sub.reset_index(drop=True).iterrows():
        r=i+4; bg=LIGHT if i%2==0 else "FFFFFF"
        fname=row.get("Faculty Name","")
        for j,v in enumerate([i+1,fname,int(row["Faculty ID"]) if pd.notna(row["Faculty ID"]) else None,
                               row.get("_Cap"),row.get("_Int"),row.get("_Th"),row.get("_Tot"),"✓"],1):
            c=ws2.cell(row=r,column=j,value=v)
            c.font=Font(name="Arial",size=9,bold=(j==7),
                        color="27AE60" if j==8 else DARK)
            c.fill=PatternFill("solid",fgColor=SUP_VAL if j==7 else bg)
            c.alignment=Alignment(horizontal="left" if j==2 else "center",vertical="center")
            if j in (4,5,6,7) and isinstance(v,float): c.number_format="0.000"
        ws2.row_dimensions[r].height=15

    buf=io.BytesIO(); wb.save(buf); buf.seek(0)
    return buf


def show():
    st.title("🔗 Audit Merge")
    st.markdown(
        "Merge **Capstone / Internship / Thesis** supervision workload "
        "into the COE FT/PT Payment Audit file. "
        "Faculty matched by **Faculty ID**."
    )

    col1, col2 = st.columns(2)
    with col1:
        audit_f = st.file_uploader(
            "1️⃣  Audit File (COE FT/PT Payment Form)",
            type=["xlsx","xls"], key="audit")
    with col2:
        sup_f = st.file_uploader(
            "2️⃣  Supervision Workload File (Book5 format)",
            type=["xlsx","xls"], key="sup")

    sheet = st.text_input(
        "Audit sheet name (leave blank to auto-detect)",
        value="FT-PT Payment AY2026 (2)")

    if not audit_f or not sup_f:
        st.info("👆 Upload both files above to continue.")
        return

    if st.button("🔗  Merge & Generate Report", type="primary",
                 use_container_width=True):
        with st.spinner("Loading and merging files…"):
            try:
                sup_df = load_supervision(sup_f)
                audit_df, sheet_used = load_audit(audit_f, sheet or None)
                merged = merge(audit_df, sup_df)
                buf = build_excel(merged, source_name=audit_f.name)
            except Exception as e:
                st.error(f"Error: {e}")
                import traceback; st.code(traceback.format_exc())
                return

        matched = int(merged["_matched"].sum())
        total_f = merged["Faculty ID"].nunique()
        st.success("✅  Done!")
        c1,c2,c3 = st.columns(3)
        c1.metric("Total audit rows",      f"{len(merged):,}")
        c2.metric("Unique faculty",         f"{total_f}")
        c3.metric("Faculty with sup. WL",   f"{matched}",
                  delta=f"{matched}/{total_f} matched")
        st.caption(f"Sheet used: **{sheet_used}**")

        from datetime import datetime
        fname = f"Audit_Merged_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
        st.download_button(
            label="⬇️  Download Merged Audit Excel",
            data=buf, file_name=fname,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True)
