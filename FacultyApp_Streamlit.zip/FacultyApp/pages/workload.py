"""pages/workload.py — Workload Report page"""

import io, math, pandas as pd, streamlit as st
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

NAVY="1B3A6B"; TEAL="0E7C7B"; WHITE="FFFFFF"
LIGHT="EEF2FA"; LIGHT2="E8F5F3"; GOLD="F5A623"
RED="E74C3C"; ORANGE="E67E22"; GREEN="27AE60"; GRAY="95A5A6"
TERM_PALETTE=["1B3A6B","0E7C7B","7B3A1B","2E5944","5C4033","3D6B9E"]
TERM_LABELS={"2501":"Fall 2501","2502":"Winter 2502",
             "2503":"Spring 2503","2504":"Summer 2504"}

def label_term(x):
    s=str(x).strip().split(".")[0]
    return TERM_LABELS.get(s, f"Term {s}")

def classify(row):
    title=str(row.get("Course Title","")).lower()
    code =str(row.get("Course Code", "")).upper()
    if "thesis"     in title: return "Thesis"
    if "internship" in title or "399" in code or "398" in code: return "UG_Internship"
    return "Capstone"

def cap_wl(cr,n):
    n=min(n,15)
    if cr>=3: return math.ceil(n/5)*1.0 if n>=3 else (1/3)*n
    else:     return math.ceil(n/5)*(cr/3) if n>=3 else (cr/3/3)*n

def int_wl(cr,n):
    nm=min(n,18)
    if cr>=6:   return math.ceil(nm/6)*2.0 if nm>=6 else (2/6)*nm
    elif cr>=3: return math.ceil(nm/6)*1.0 if nm>=6 else (1/6)*nm
    else:       return (cr/3/6)*nm

def calc_wl(row):
    k,c,n=row["Key"],row["Course_Credits"],row["Student_Count"]
    if k=="Capstone": return cap_wl(c,n)
    if k=="UG_Internship": return int_wl(c,n)
    if k=="Thesis": return 0.5
    return 0

def process_raw(df):
    df.columns=[str(c).strip() for c in df.columns]
    rename={}
    for col in df.columns:
        cl=col.lower()
        if "supervisor" in cl:                          rename[col]="Supervisor"
        elif cl=="id" or cl=="student id":              rename[col]="ID"
        elif "credit" in cl:                            rename[col]="Course_Credits"
        elif "class" in cl and "nbr" in cl:             rename[col]="Class Nbr"
        elif "course" in cl and "title" in cl:          rename[col]="Course Title"
        elif "course" in cl and "code" in cl:           rename[col]="Course Code"
        elif "enrollment" in cl and "term" in cl:       rename[col]="Enrollment Term"
        elif cl=="section":                             rename[col]="Section"
    df=df.rename(columns=rename)
    for col in ["Supervisor","Course Code","Course Title","Course_Credits",
                "Class Nbr","Section","Enrollment Term"]:
        if col not in df.columns:
            raise ValueError(f"Column '{col}' not found. Found: {list(df.columns)}")
    df=df[df["Supervisor"].notna()].copy()
    df["Supervisor"]=df["Supervisor"].astype(str).str.strip()
    df["Course_Credits"]=pd.to_numeric(df["Course_Credits"],errors="coerce")
    df["Class Nbr"]=pd.to_numeric(df["Class Nbr"],errors="coerce")
    df["Enrollment Term"]=pd.to_numeric(df["Enrollment Term"],errors="coerce")
    df=df[df["Course_Credits"].notna()].copy()
    df=df[~df["Course Code"].isin(["Course Code","0"])].copy()
    df["Key"]=df.apply(classify,axis=1)
    sec=df.groupby(["Supervisor","Key","Course Code","Course Title",
                    "Course_Credits","Class Nbr","Section","Enrollment Term"]
                   ).agg(Student_Count=("ID","count")).reset_index()
    sec["Term"]=sec["Enrollment Term"].apply(label_term)
    sec["Workload"]=sec.apply(calc_wl,axis=1)
    return sec

def build_excel(df_all):
    all_terms=sorted(df_all["Term"].unique(),
                     key=lambda t: t.split()[-1] if t.split() else t)
    tc={t: TERM_PALETTE[i%len(TERM_PALETTE)] for i,t in enumerate(all_terms)}
    df_all=df_all.copy()
    df_all["_to"]=df_all["Term"].apply(lambda t: all_terms.index(t) if t in all_terms else 99)
    summary=df_all.groupby(["Supervisor","Key"])["Workload"].sum().unstack(fill_value=0).reset_index()
    for k in ["Capstone","UG_Internship","Thesis"]:
        if k not in summary.columns: summary[k]=0
    summary["Total"]=summary["Capstone"]+summary["UG_Internship"]+summary["Thesis"]
    summary=summary.sort_values("Total",ascending=False).reset_index(drop=True)
    summary.columns=["Supervisor","Capstone","UG_Internship","Thesis","Total"]
    tp=df_all.groupby(["Supervisor","Term"])["Workload"].sum().unstack(fill_value=0).reset_index()
    for t in all_terms:
        if t not in tp.columns: tp[t]=0
    summary=summary.merge(tp[["Supervisor"]+all_terms],on="Supervisor",how="left")
    for t in all_terms: summary[t]=summary[t].fillna(0)
    sup_sec=df_all.groupby("Supervisor")["Class Nbr"].nunique().to_dict()

    def H(ws,r,c,v,bg=NAVY,fg=WHITE,bold=True,sz=9,ha="center",wrap=False):
        cell=ws.cell(row=r,column=c,value=v)
        cell.font=Font(name="Arial",bold=bold,color=fg,size=sz)
        cell.fill=PatternFill("solid",fgColor=bg)
        cell.alignment=Alignment(horizontal=ha,vertical="center",wrap_text=wrap)
        return cell

    def D(ws,r,c,v,bg=WHITE,bold=False,sz=9,ha="center",fmt=None,fg="111111"):
        cell=ws.cell(row=r,column=c,value=v)
        cell.font=Font(name="Arial",bold=bold,color=fg,size=sz)
        cell.fill=PatternFill("solid",fgColor=bg)
        cell.alignment=Alignment(horizontal=ha,vertical="center")
        if fmt and isinstance(v,(int,float)): cell.number_format=fmt
        return cell

    wb=Workbook()
    ws1=wb.active; ws1.title="Dashboard"
    ws1.sheet_view.showGridLines=False
    ws1.row_dimensions[1].height=6
    n_dc=7+len(all_terms)
    ws1.merge_cells(f"A2:{get_column_letter(n_dc)}2")
    H(ws1,2,1,f"FACULTY WORKLOAD CALCULATOR — {' + '.join(all_terms)}",sz=13)
    ws1.row_dimensions[2].height=36
    ws1.merge_cells(f"A3:{get_column_letter(n_dc)}3")
    H(ws1,3,1,"Capstone: CEIL(n/5) blocks (max 15)  |  Internship: CEIL(n/6) blocks (max 18)  |  Thesis: 0.5 per thesis",bg=TEAL,sz=10)
    ws1.row_dimensions[3].height=20; ws1.row_dimensions[4].height=8

    kpis=[("A","Supervisors",int(len(summary)),NAVY),
          ("B","Total Students",int(df_all["Student_Count"].sum()),TEAL),
          ("C","Capstone WL",round(float(summary["Capstone"].sum()),2),"2E4057"),
          ("D","Internship WL",round(float(summary["UG_Internship"].sum()),2),"048A81"),
          ("E","Thesis WL",round(float(summary["Thesis"].sum()),2),"5C4033"),
          ("F","Grand Total",round(float(summary["Total"].sum()),2),NAVY)]
    for cl,lbl,val,bg in kpis:
        c=ws1[f"{cl}5"]; c.value=lbl
        c.font=Font(name="Arial",size=8,color="AACCEE"); c.fill=PatternFill("solid",fgColor=bg)
        c.alignment=Alignment(horizontal="center",vertical="center")
        c=ws1[f"{cl}6"]; c.value=val
        c.font=Font(name="Arial",size=12,bold=True,color=WHITE); c.fill=PatternFill("solid",fgColor=bg)
        c.alignment=Alignment(horizontal="center",vertical="center")
    ws1.row_dimensions[5].height=16; ws1.row_dimensions[6].height=26; ws1.row_dimensions[7].height=8

    hdrs=["#","Supervisor","Capstone\nWL","Intern.\nWL","Thesis\nWL","Total\nWL"]
    wdths=[4,42,12,13,11,12]
    for t in all_terms:
        sh=t.replace("Fall ","F-").replace("Winter ","W-").replace("Spring ","S-")
        hdrs.append(sh+"\nWL"); wdths.append(11)
    hdrs.append("Sections"); wdths.append(9)
    hdrs.append("Category"); wdths.append(14)

    for j,(h,w) in enumerate(zip(hdrs,wdths),1):
        ws1.column_dimensions[get_column_letter(j)].width=w
        idx=j-7; hbg=tc.get(all_terms[idx],NAVY) if 6<j<=6+len(all_terms) else NAVY
        c=ws1.cell(row=8,column=j,value=h)
        c.font=Font(name="Arial",bold=True,size=9,color=WHITE)
        c.fill=PatternFill("solid",fgColor=hbg)
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        c.border=Border(bottom=Side(style="medium",color=GOLD))
    ws1.row_dimensions[8].height=32

    for i,row in summary.iterrows():
        r=i+9; bg=LIGHT if i%2==0 else WHITE; total=round(float(row["Total"]),4)
        D(ws1,r,1,i+1,bg=bg,ha="center",sz=9,fg="999999")
        D(ws1,r,2,row["Supervisor"],bg=bg,bold=(i<5),ha="left",sz=10)
        for j,col in enumerate(["Capstone","UG_Internship","Thesis"],3):
            v=round(float(row[col]),4)
            D(ws1,r,j,v if v>0 else "-",bg=bg,fmt="0.000" if v>0 else None)
        tbg,tfg=(RED,WHITE) if total>=5 else (ORANGE,WHITE) if total>=3 else (bg,NAVY)
        c=ws1.cell(row=r,column=6,value=total); c.number_format="0.000"
        c.font=Font(name="Arial",size=10,bold=True,color=tfg)
        c.fill=PatternFill("solid",fgColor=tbg)
        c.alignment=Alignment(horizontal="center",vertical="center")
        for j,term in enumerate(all_terms,7):
            v=round(float(row[term]),4); tl=["E8EEFF","E8F8F5","FEF0E8","F0FFF0"][list(all_terms).index(term)%4]
            c=ws1.cell(row=r,column=j,value=v if v>0 else "-")
            if v>0: c.number_format="0.000"
            c.font=Font(name="Arial",size=9,color=NAVY if v>0 else GRAY)
            c.fill=PatternFill("solid",fgColor=tl if bg==LIGHT else WHITE)
            c.alignment=Alignment(horizontal="center",vertical="center")
        D(ws1,r,7+len(all_terms),int(sup_sec.get(row["Supervisor"],0)),bg=bg)
        cat,cbg=("High Load",RED) if total>=5 else ("Moderate",ORANGE) if total>=3 else ("Normal",GREEN) if total>=1 else ("Low",GRAY)
        c=ws1.cell(row=r,column=8+len(all_terms),value=cat)
        c.font=Font(name="Arial",size=9,bold=True,color=WHITE)
        c.fill=PatternFill("solid",fgColor=cbg)
        c.alignment=Alignment(horizontal="center",vertical="center")
        ws1.row_dimensions[r].height=17

    tr=len(summary)+9
    ws1.merge_cells(f"A{tr}:B{tr}")
    c=ws1.cell(row=tr,column=1,value="TOTAL")
    c.font=Font(name="Arial",bold=True,size=11,color=WHITE); c.fill=PatternFill("solid",fgColor=NAVY)
    c.alignment=Alignment(horizontal="center",vertical="center")
    for j,col in enumerate(["Capstone","UG_Internship","Thesis","Total"],3):
        c=ws1.cell(row=tr,column=j,value=round(float(summary[col].sum()),4))
        c.number_format="0.000"; c.font=Font(name="Arial",bold=True,size=11,color=WHITE)
        c.fill=PatternFill("solid",fgColor=NAVY); c.alignment=Alignment(horizontal="center",vertical="center")
    for j,term in enumerate(all_terms,7):
        c=ws1.cell(row=tr,column=j,value=round(float(summary[term].sum()),4))
        c.number_format="0.000"; c.font=Font(name="Arial",bold=True,size=11,color=WHITE)
        c.fill=PatternFill("solid",fgColor=NAVY); c.alignment=Alignment(horizontal="center",vertical="center")
    ws1.row_dimensions[tr].height=22; ws1.freeze_panes="A9"

    # Section Detail sheet
    ws2=wb.create_sheet("Section Detail"); ws2.sheet_view.showGridLines=False
    ws2.row_dimensions[1].height=6
    ws2.merge_cells("A2:M2")
    H(ws2,2,1,f"SECTION-LEVEL WORKLOAD DETAIL — {' + '.join(all_terms)}",bg=TEAL,sz=12)
    ws2.row_dimensions[2].height=26; ws2.row_dimensions[3].height=6
    KCL={"Capstone":NAVY,"UG_Internship":TEAL,"Thesis":"5C4033"}
    sh=["Supervisor","Term","Type","Course Code","Course Title","Credits",
        "Class Nbr","Sec","Students","Workload"]
    sw=[34,12,15,12,34,7,10,6,10,11]
    for j,(h,w) in enumerate(zip(sh,sw),1):
        ws2.column_dimensions[get_column_letter(j)].width=w
        c=ws2.cell(row=4,column=j,value=h)
        c.font=Font(name="Arial",bold=True,size=9,color=WHITE); c.fill=PatternFill("solid",fgColor=NAVY)
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
    ws2.row_dimensions[4].height=26
    ds=df_all.sort_values(["Supervisor","_to","Key","Course Code"]).reset_index(drop=True)
    for i,row in ds.iterrows():
        r=i+5; bg=LIGHT if i%2==0 else WHITE; k=str(row.get("Key",""))
        D(ws2,r,1,row["Supervisor"],bg=bg,ha="left",sz=9)
        c=ws2.cell(row=r,column=2,value=row["Term"])
        c.font=Font(name="Arial",size=8,bold=True,color=WHITE)
        c.fill=PatternFill("solid",fgColor=tc.get(row["Term"],NAVY))
        c.alignment=Alignment(horizontal="center",vertical="center")
        c=ws2.cell(row=r,column=3,value=k)
        c.font=Font(name="Arial",size=8,bold=True,color=WHITE)
        c.fill=PatternFill("solid",fgColor=KCL.get(k,NAVY))
        c.alignment=Alignment(horizontal="center",vertical="center")
        D(ws2,r,4,row["Course Code"],bg=bg,sz=9)
        D(ws2,r,5,row["Course Title"],bg=bg,sz=9,ha="left")
        D(ws2,r,6,row["Course_Credits"],bg=bg,sz=9,fmt="0.0")
        D(ws2,r,7,row["Class Nbr"],bg=bg,sz=9)
        D(ws2,r,8,row["Section"],bg=bg,sz=9)
        D(ws2,r,9,int(row["Student_Count"]),bg=bg,sz=10,bold=True)
        c=ws2.cell(row=r,column=10,value=round(float(row["Workload"]),4))
        c.number_format="0.000"; c.font=Font(name="Arial",bold=True,size=10)
        c.fill=PatternFill("solid",fgColor=bg); c.alignment=Alignment(horizontal="center",vertical="center")
        ws2.row_dimensions[r].height=15
    ws2.freeze_panes="A5"

    buf=io.BytesIO(); wb.save(buf); buf.seek(0)
    return buf, {"supervisors":len(summary),"sections":len(df_all),
                 "students":int(df_all["Student_Count"].sum()),
                 "grand_total":round(float(summary["Total"].sum()),3),
                 "terms":all_terms}


def show():
    st.title("📊 Workload Report")
    st.markdown(
        "Upload one or more student data files to generate a full "
        "Capstone / Internship / Thesis workload report using the block-based formula."
    )

    with st.expander("📋 Formula reference", expanded=False):
        st.markdown("""
| Type | Scenario | Formula |
|------|----------|---------|
| Capstone | A.1: credits≥3, n≥3 | `CEIL(n/5) × 1.0` |
| Capstone | A.2: credits≥3, n<3 | `(1/3) × n` |
| Capstone | B.1: credits<3, n≥3 | `CEIL(n/5) × (credits/3)` |
| Capstone | B.2: credits<3, n<3 | `(credits/3/3) × n` |
| Internship | Scen-A: 3cr, n<6 | `(1/6) × n` |
| Internship | Blk-A: 3cr, n≥6 | `CEIL(n/6) × 1.0` |
| Internship | Scen-B: ≥6cr, n<6 | `(2/6) × n` |
| Internship | Blk-B: ≥6cr, n≥6 | `CEIL(n/6) × 2.0` |
| Internship | Scen-C: cr<3 | `(credits/3/6) × n` |
| Thesis | Any | `0.5 per thesis` |
        """)

    files = st.file_uploader(
        "Upload raw student data file(s)",
        type=["xlsx","xls"],
        accept_multiple_files=True,
        help="Each file should have: Supervisor, Course Code, Course_Credits, Class Nbr, Section, Enrollment Term, ID"
    )

    if not files:
        st.info("👆 Upload one or more files. You can combine multiple terms.")
        return

    st.write(f"**{len(files)} file(s) uploaded:**",
             ", ".join(f.name for f in files))

    if st.button("📊  Generate Workload Report", type="primary",
                 use_container_width=True):
        all_sections = []
        errors = []
        prog = st.progress(0)
        for i, f in enumerate(files):
            with st.spinner(f"Processing {f.name}…"):
                try:
                    df_raw = pd.read_excel(f, header=0)
                    sec = process_raw(df_raw)
                    # Infer term from filename if needed
                    fname = f.name.lower()
                    if "Term" not in sec.columns or sec["Term"].eq("Unknown").all():
                        if   "spring" in fname: sec["Term"]="Spring 2503"
                        elif "winter" in fname: sec["Term"]="Winter 2502"
                        elif "fall"   in fname: sec["Term"]="Fall 2501"
                    all_sections.append(sec)
                except Exception as e:
                    errors.append(f"{f.name}: {e}")
            prog.progress((i+1)/len(files))

        if errors:
            for err in errors:
                st.error(err)
            if not all_sections:
                return

        df_all = pd.concat(all_sections, ignore_index=True)
        df_all = df_all[df_all["Workload"].notna()].copy()

        with st.spinner("Building Excel report…"):
            buf, stats = build_excel(df_all)

        st.success("✅  Done!")
        c1,c2,c3,c4 = st.columns(4)
        c1.metric("Supervisors", stats["supervisors"])
        c2.metric("Sections",    stats["sections"])
        c3.metric("Students",    stats["students"])
        c4.metric("Grand Total WL", stats["grand_total"])

        from datetime import datetime
        fname = f"Workload_Report_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
        st.download_button(
            label="⬇️  Download Workload Report",
            data=buf, file_name=fname,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True)
