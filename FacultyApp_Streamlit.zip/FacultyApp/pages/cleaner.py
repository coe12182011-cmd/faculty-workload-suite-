"""pages/cleaner.py — Faculty Cleaner page"""

import io, math
import pandas as pd
import streamlit as st
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ── CONSTANTS ─────────────────────────────────────────────────────────────────
TYPE_PRIORITY = {
    "LEC":9,"MIX":8,"LAB":7,"STU":6,"VC":5,
    "FLD":4,"PRA":3,"RSC":2,"THE":1,"NON":0,
}
NAVY="1B3A6B"; TEAL="0E7C7B"; WHITE="FFFFFF"
LIGHT="EEF2FA"; LIGHT2="F5F8FF"; GOLD="F5A623"
GRAY="95A5A6"; DARK="2C3E50"; TOTAL_BG="0A3D62"
TERM_COLORS={"2501":"1B3A6B","2502":"0E7C7B","2503":"7B3A1B","2504":"2E5944"}
ROLE_COLORS={"Primary Instructor":"1B3A6B","Secondary Instructor":"0E7C7B",
             "Teaching Assistant":"5C4033"}
TYPE_COLORS={"LEC":"2E4057","MIX":"0E7C7B","LAB":"5C4033","STU":"6B3A7B",
             "VC":"3A6B1B","NON":GRAY,"RSC":"7B5A1B","FLD":"1B6B5C","THE":"4A1B6B"}
COL_WIDTHS={
    "ID":10,"Name":26,"Term":6,"Session":8,"Campus":8,"Subject":8,
    "Course Career":9,"Descr":8,"Course ID":10,"Section":7,"Class Nbr":10,
    "Facil ID":10,"Mtg Start":9,"Mtg End":9,"Start Date":12,"End Date":12,
    "Cap Enrl":7,"Tot Enrl":7,"Max Units":8,"Pat":6,"Assign Type":9,
    "Role":18,"Assignment %":11,"Long Title":36,"Description":22,"Email":28,
    "Total Assignment %":14,
}

def total_colour(v):
    if   v>=30: return "E74C3C",WHITE
    elif v>=18: return "E67E22",WHITE
    elif v>= 9: return "27AE60",WHITE
    else:       return "DDEEFF",TOTAL_BG


# ── CLEAN LOGIC ───────────────────────────────────────────────────────────────
def clean(df_raw):
    df = df_raw.copy()
    df.columns = [str(c).strip() for c in df.columns]
    df = df[df["Name"].notna()].copy()
    df["Name"]         = df["Name"].astype(str).str.strip()
    df["Assignment %"] = pd.to_numeric(df["Assignment %"], errors="coerce").fillna(0)
    df["Class Nbr"]    = pd.to_numeric(df["Class Nbr"],    errors="coerce")
    df["Section"]      = pd.to_numeric(df["Section"],      errors="coerce")
    df["_pri"] = df["Assign Type"].apply(
        lambda t: TYPE_PRIORITY.get(str(t).strip().upper(), 0))
    sorted_df = df.sort_values(
        ["Name","Class Nbr","Section","Assignment %","_pri"],
        ascending=[True,True,True,False,False])
    clean_df  = sorted_df.drop_duplicates(
        subset=["Name","Class Nbr","Section"], keep="first").drop(columns=["_pri"])
    removed   = df.loc[list(set(df.index) - set(clean_df.index))].drop(
        columns=["_pri"]).sort_values(["Name","Class Nbr","Section"])
    sort_cols = [c for c in ["Name","Term","Class Nbr"] if c in clean_df.columns]
    clean_df  = clean_df.sort_values(sort_cols).reset_index(drop=True)
    return clean_df, removed


# ── EXCEL BUILDER ─────────────────────────────────────────────────────────────
def build_excel(df_clean, df_removed, source_name=""):
    orig_cols  = list(df_clean.columns)
    all_cols   = orig_cols + ["Total Assignment %"]
    n_cols     = len(all_cols)
    DATA_START = 6
    MAX_ROW    = DATA_START + len(df_clean) - 1

    name_idx   = orig_cols.index("Name") + 1
    assign_idx = orig_cols.index("Assignment %") + 1
    NL = get_column_letter(name_idx)
    AL = get_column_letter(assign_idx)
    TL = get_column_letter(n_cols)

    def sumif_r(r):
        return (f"=SUMIF(${NL}${DATA_START}:${NL}${MAX_ROW},"
                f"{NL}{r},${AL}${DATA_START}:${AL}${MAX_ROW})")

    def sumif_s2(fr):
        return (f"=SUMIF('Cleaned Data'!${NL}${DATA_START}:"
                f"'Cleaned Data'!${NL}${MAX_ROW},"
                f"'Cleaned Data'!{NL}{fr},"
                f"'Cleaned Data'!${AL}${DATA_START}:"
                f"'Cleaned Data'!${AL}${MAX_ROW})")

    totals_map = df_clean.groupby("Name")["Assignment %"].sum().to_dict()

    def H(ws,r,c,v,bg=NAVY,fg=WHITE,bold=True,sz=9,ha="center",wrap=False):
        cell=ws.cell(row=r,column=c,value=v)
        cell.font=Font(name="Arial",bold=bold,color=fg,size=sz)
        cell.fill=PatternFill("solid",fgColor=bg)
        cell.alignment=Alignment(horizontal=ha,vertical="center",wrap_text=wrap)
        return cell

    wb = Workbook()

    # ── Sheet 1: Cleaned Data ─────────────────────────────────────────────────
    ws = wb.active; ws.title = "Cleaned Data"
    ws.sheet_view.showGridLines = False
    ws.row_dimensions[1].height = 6

    ws.merge_cells(f"A2:{TL}2")
    c=ws["A2"]
    c.value=(f"FACULTY COURSE LIST — CLEANED"
             +(f"  |  {source_name}" if source_name else "")
             +f"  ({len(df_clean):,} records | {df_clean['Name'].nunique()} faculty)")
    c.font=Font(name="Arial",bold=True,size=13,color=WHITE)
    c.fill=PatternFill("solid",fgColor=NAVY)
    c.alignment=Alignment(horizontal="center",vertical="center")
    ws.row_dimensions[2].height=30

    ws.merge_cells(f"A3:{TL}3")
    c=ws["A3"]
    c.value=("  Duplicates removed — kept highest Assignment % per (Faculty · Class Nbr · Section)  |  "
             "Sorted A→Z by Faculty Name  |  "
             "⚡ 'Total Assignment %' = SUMIF formula — auto-updates when rows are deleted")
    c.font=Font(name="Arial",size=9,italic=True,color="CCDDEE")
    c.fill=PatternFill("solid",fgColor=TEAL)
    c.alignment=Alignment(horizontal="left",vertical="center")
    ws.row_dimensions[3].height=18
    ws.row_dimensions[4].height=6

    for j,col in enumerate(all_cols,1):
        ws.column_dimensions[get_column_letter(j)].width=COL_WIDTHS.get(col,12)
        is_t=(col=="Total Assignment %")
        c=ws.cell(row=5,column=j,value=col)
        c.font=Font(name="Arial",bold=True,size=9,color=WHITE)
        c.fill=PatternFill("solid",fgColor=TOTAL_BG if is_t else NAVY)
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        c.border=Border(bottom=Side(style="medium",color="00CCFF" if is_t else GOLD))
    ws.row_dimensions[5].height=28

    prev_name=None; fi=-1; bgs=[LIGHT,LIGHT2]; nfr={}
    for i,(_,row) in enumerate(df_clean.iterrows()):
        r=i+DATA_START; nm=row["Name"]
        is_new=(nm!=prev_name)
        if is_new: fi+=1; prev_name=nm; nfr[nm]=r
        bg=bgs[fi%2]
        for j,col in enumerate(all_cols,1):
            cell=ws.cell(row=r,column=j)
            is_t=(col=="Total Assignment %")
            if is_t:
                cell.value=sumif_r(r); cell.number_format="0.00"
                tbg,tfg=total_colour(totals_map.get(nm,0))
                cell.font=Font(name="Arial",bold=True,size=10,color=tfg)
                cell.fill=PatternFill("solid",fgColor=tbg)
                cell.alignment=Alignment(horizontal="center",vertical="center")
                cell.border=Border(
                    left=Side(style="medium",color=TOTAL_BG),
                    right=Side(style="medium",color=TOTAL_BG),
                    top=Side(style="thin",color="9AAAC4" if is_new else "CCDDFF"))
                continue
            val=row[col]
            if col=="Name":
                cell.value=str(val) if pd.notna(val) else ""
                cell.font=Font(name="Arial",size=9,bold=is_new,color=DARK)
                cell.fill=PatternFill("solid",fgColor="DCE8FF" if is_new else bg)
                cell.alignment=Alignment(horizontal="left",vertical="center")
            elif col=="Role":
                v=str(val).strip() if pd.notna(val) else ""
                cell.value=v; cell.font=Font(name="Arial",size=8,bold=True,color=WHITE)
                cell.fill=PatternFill("solid",fgColor=ROLE_COLORS.get(v,DARK))
                cell.alignment=Alignment(horizontal="center",vertical="center")
            elif col=="Term":
                v=str(val).strip() if pd.notna(val) else ""
                cell.value=v; cell.font=Font(name="Arial",size=9,bold=True,color=WHITE)
                cell.fill=PatternFill("solid",fgColor=TERM_COLORS.get(v,NAVY))
                cell.alignment=Alignment(horizontal="center",vertical="center")
            elif col=="Assign Type":
                v=str(val).strip() if pd.notna(val) else ""
                cell.value=v; cell.font=Font(name="Arial",size=9,bold=True,color=WHITE)
                cell.fill=PatternFill("solid",fgColor=TYPE_COLORS.get(v,DARK))
                cell.alignment=Alignment(horizontal="center",vertical="center")
            elif col=="Assignment %":
                v=pd.to_numeric(val,errors="coerce")
                cell.value=float(v) if pd.notna(v) else 0
                cell.number_format="0.0"
                cell.font=Font(name="Arial",size=9,
                               bold=(float(v)>0 if pd.notna(v) else False),
                               color=NAVY if (pd.notna(v) and float(v)>0) else GRAY)
                cell.fill=PatternFill("solid",fgColor=bg)
                cell.alignment=Alignment(horizontal="center",vertical="center")
            elif col in ("Start Date","End Date"):
                cell.value=pd.to_datetime(val) if pd.notna(val) else None
                if pd.notna(val): cell.number_format="DD-MMM-YYYY"
                cell.font=Font(name="Arial",size=8)
                cell.fill=PatternFill("solid",fgColor=bg)
                cell.alignment=Alignment(horizontal="center",vertical="center")
            elif col in ("Cap Enrl","Tot Enrl","Class Nbr","Course ID","ID","Section"):
                v=pd.to_numeric(val,errors="coerce")
                cell.value=int(v) if pd.notna(v) else None
                cell.font=Font(name="Arial",size=9,color=DARK)
                cell.fill=PatternFill("solid",fgColor=bg)
                cell.alignment=Alignment(horizontal="center",vertical="center")
            elif col in ("Long Title","Description","Email"):
                cell.value=str(val).strip() if pd.notna(val) else ""
                cell.font=Font(name="Arial",size=9,
                               italic=(col=="Email"),
                               color="1155CC" if col=="Email" else DARK)
                cell.fill=PatternFill("solid",fgColor=bg)
                cell.alignment=Alignment(horizontal="left",vertical="center")
            else:
                cell.value=str(val).strip() if pd.notna(val) else None
                cell.font=Font(name="Arial",size=9,color=DARK)
                cell.fill=PatternFill("solid",fgColor=bg)
                cell.alignment=Alignment(horizontal="center",vertical="center")
            if is_new:
                cell.border=Border(top=Side(style="thin",color="9AAAC4"))
        ws.row_dimensions[r].height=15
    ws.freeze_panes="A6"

    # ── Sheet 2: Faculty Summary ──────────────────────────────────────────────
    ws2=wb.create_sheet("Faculty Summary"); ws2.sheet_view.showGridLines=False
    ws2.row_dimensions[1].height=6
    ws2.merge_cells("A2:G2")
    c=ws2["A2"]
    c.value=f"FACULTY SUMMARY — {df_clean['Name'].nunique()} faculty  |  {len(df_clean):,} sections"
    c.font=Font(name="Arial",bold=True,size=13,color=WHITE)
    c.fill=PatternFill("solid",fgColor=NAVY)
    c.alignment=Alignment(horizontal="center",vertical="center")
    ws2.row_dimensions[2].height=28
    ws2.merge_cells("A3:G3")
    c=ws2["A3"]
    c.value=("  ⚡ 'Total Assign %' uses cross-sheet SUMIF — "
             "deleting rows in Cleaned Data auto-updates these totals (Ctrl+Alt+F9)")
    c.font=Font(name="Arial",size=9,italic=True,color="555555")
    c.fill=PatternFill("solid",fgColor="DDEEFF")
    c.alignment=Alignment(horizontal="left",vertical="center")
    ws2.row_dimensions[3].height=16; ws2.row_dimensions[4].height=8

    fsum=(df_clean.groupby("Name").agg(
        Sections=("Class Nbr","count"),
        Terms=("Term",lambda x:", ".join(sorted(x.dropna().astype(str).unique()))),
        Courses=("Descr","nunique"),
        Campuses=("Campus",lambda x:", ".join(sorted(x.dropna().astype(str).unique()))),
        Roles=("Role",lambda x:", ".join(sorted(x.dropna().astype(str).unique()))))
        .reset_index().sort_values("Name").reset_index(drop=True))

    hdrs=["#","Faculty Name","Sections","Total Assign %","Terms","Campus(es)","Role(s)"]
    wids=[4,32,10,14,18,16,30]
    for j,(h,w) in enumerate(zip(hdrs,wids),1):
        ws2.column_dimensions[get_column_letter(j)].width=w
        is_t=(h=="Total Assign %")
        c=ws2.cell(row=5,column=j,value=h)
        c.font=Font(name="Arial",bold=True,size=9,color=WHITE)
        c.fill=PatternFill("solid",fgColor=TOTAL_BG if is_t else NAVY)
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        c.border=Border(bottom=Side(style="medium",color="00CCFF" if is_t else GOLD))
    ws2.row_dimensions[5].height=22

    for i,row in fsum.iterrows():
        r=i+6; bg=LIGHT if r%2==0 else LIGHT2; nm=row["Name"]
        c=ws2.cell(row=r,column=1,value=i+1)
        c.font=Font(name="Arial",size=9,color=GRAY); c.fill=PatternFill("solid",fgColor=bg)
        c.alignment=Alignment(horizontal="center",vertical="center")
        c=ws2.cell(row=r,column=2,value=nm)
        c.font=Font(name="Arial",size=9,bold=True,color=DARK); c.fill=PatternFill("solid",fgColor=bg)
        c.alignment=Alignment(horizontal="left",vertical="center")
        c=ws2.cell(row=r,column=3,value=row["Sections"])
        c.font=Font(name="Arial",size=9); c.fill=PatternFill("solid",fgColor=bg)
        c.alignment=Alignment(horizontal="center",vertical="center")
        fr=nfr.get(nm,DATA_START)
        tbg,tfg=total_colour(totals_map.get(nm,0))
        c=ws2.cell(row=r,column=4,value=sumif_s2(fr))
        c.number_format="0.00"
        c.font=Font(name="Arial",size=10,bold=True,color=tfg)
        c.fill=PatternFill("solid",fgColor=tbg)
        c.alignment=Alignment(horizontal="center",vertical="center")
        for j,col in enumerate(["Terms","Campuses","Roles"],5):
            c=ws2.cell(row=r,column=j,value=row[col])
            c.font=Font(name="Arial",size=9,color=DARK); c.fill=PatternFill("solid",fgColor=bg)
            c.alignment=Alignment(horizontal="left",vertical="center")
        ws2.row_dimensions[r].height=15

    tr=len(fsum)+6
    ws2.merge_cells(f"A{tr}:C{tr}")
    c=ws2.cell(row=tr,column=1,value="GRAND TOTAL")
    c.font=Font(name="Arial",bold=True,size=11,color=WHITE); c.fill=PatternFill("solid",fgColor=NAVY)
    c.alignment=Alignment(horizontal="center",vertical="center")
    c=ws2.cell(row=tr,column=4,value=f"=SUM(D6:D{tr-1})")
    c.number_format="0.00"; c.font=Font(name="Arial",bold=True,size=11,color=WHITE)
    c.fill=PatternFill("solid",fgColor=NAVY); c.alignment=Alignment(horizontal="center",vertical="center")
    for j in [5,6,7]: ws2.cell(row=tr,column=j).fill=PatternFill("solid",fgColor=NAVY)
    ws2.row_dimensions[tr].height=22; ws2.freeze_panes="A6"

    # ── Sheet 3: Removed Rows Log ─────────────────────────────────────────────
    ws3=wb.create_sheet("Removed Rows Log"); ws3.sheet_view.showGridLines=False
    ws3.row_dimensions[1].height=6
    lc=list(df_removed.columns); nl=len(lc)
    ws3.merge_cells(f"A2:{get_column_letter(nl)}2")
    c=ws3["A2"]
    c.value=f"REMOVED ROWS LOG — {len(df_removed)} duplicate rows removed"
    c.font=Font(name="Arial",bold=True,size=12,color=WHITE)
    c.fill=PatternFill("solid",fgColor="E74C3C")
    c.alignment=Alignment(horizontal="center",vertical="center")
    ws3.row_dimensions[2].height=26
    ws3.merge_cells(f"A3:{get_column_letter(nl)}3")
    c=ws3["A3"]
    c.value=("  Removed because a higher-priority row exists for the same "
             "Faculty + Class Nbr + Section.  Rule: highest Assignment % → LEC > MIX > LAB > NON")
    c.font=Font(name="Arial",size=9,italic=True,color="555555")
    c.fill=PatternFill("solid",fgColor="FEE8E8")
    c.alignment=Alignment(horizontal="left",vertical="center")
    ws3.row_dimensions[3].height=16; ws3.row_dimensions[4].height=8
    for j,col in enumerate(lc,1):
        ws3.column_dimensions[get_column_letter(j)].width=COL_WIDTHS.get(col,12)
        c=ws3.cell(row=5,column=j,value=col)
        c.font=Font(name="Arial",bold=True,size=9,color=WHITE)
        c.fill=PatternFill("solid",fgColor="C0392B")
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
    ws3.row_dimensions[5].height=22
    for i,(_,row) in enumerate(df_removed.iterrows()):
        r=i+6; bg="FFF5F5" if i%2==0 else WHITE
        for j,col in enumerate(lc,1):
            val=row[col]
            c=ws3.cell(row=r,column=j,value=str(val).strip() if pd.notna(val) else None)
            c.font=Font(name="Arial",size=9,color="888888",italic=True)
            c.fill=PatternFill("solid",fgColor=bg)
            c.alignment=Alignment(horizontal="center",vertical="center")
        ws3.row_dimensions[r].height=14
    ws3.freeze_panes="A6"

    buf=io.BytesIO(); wb.save(buf); buf.seek(0)
    return buf


# ── PAGE ──────────────────────────────────────────────────────────────────────
def show():
    st.title("🧹 Faculty Course Cleaner")
    st.markdown(
        "Upload a faculty course assignment Excel file. "
        "The app removes duplicate rows and adds a **live SUMIF** "
        "`Total Assignment %` column that auto-recalculates when you delete rows in Excel."
    )

    # ── Rules expander ─────────────────────────────────────────────────────────
    with st.expander("📋 Cleaning rules", expanded=False):
        st.markdown("""
**For each group of rows with the same `Faculty Name + Class Nbr + Section`:**
1. Keep the row with the **highest Assignment %**
2. If tied → keep the best course type: `LEC > MIX > LAB > STU > VC > FLD > RSC > NON`
3. NON rows with 0% are almost always the ones dropped

**Output sheets:**
- **Cleaned Data** — all clean rows sorted A→Z by faculty, with SUMIF total column
- **Faculty Summary** — one row per faculty, colour-coded by total workload
- **Removed Rows Log** — full audit trail of every removed row

**Total Assignment % colour coding:**

| Colour | Range |
|---|---|
| 🔵 Light blue | < 9% |
| 🟢 Green | 9 – 17% |
| 🟠 Orange | 18 – 29% |
| 🔴 Red | ≥ 30% |
        """)

    # ── File upload ────────────────────────────────────────────────────────────
    uploaded = st.file_uploader(
        "Upload your faculty course file (.xlsx or .xls)",
        type=["xlsx", "xls"],
        help="Must contain columns: Name, Class Nbr, Section, Assignment %",
    )

    if uploaded is None:
        st.info("👆 Upload a file to get started.")
        return

    # ── Preview ────────────────────────────────────────────────────────────────
    try:
        df_raw = pd.read_excel(uploaded, header=0)
        df_raw.columns = [str(c).strip() for c in df_raw.columns]
        df_raw = df_raw[df_raw.iloc[:, 1].notna()].copy()
    except Exception as e:
        st.error(f"Could not read file: {e}")
        return

    required = {"Name", "Class Nbr", "Section", "Assignment %"}
    missing  = required - set(df_raw.columns)
    if missing:
        st.error(f"Missing required columns: {missing}")
        st.write("Columns found:", list(df_raw.columns))
        return

    col1, col2, col3 = st.columns(3)
    col1.metric("Total rows", f"{len(df_raw):,}")
    col2.metric("Unique faculty", f"{df_raw['Name'].dropna().nunique()}")
    col3.metric("Unique class sections",
                f"{df_raw.groupby(['Name','Class Nbr','Section']).ngroups:,}")

    with st.expander("👀 Preview raw data (first 20 rows)"):
        st.dataframe(df_raw.head(20), use_container_width=True)

    # ── Run button ─────────────────────────────────────────────────────────────
    st.markdown("---")
    if st.button("🧹  Clean & Generate Excel", type="primary", use_container_width=True):
        with st.spinner("Cleaning data and building Excel report…"):
            try:
                df_clean, df_removed = clean(df_raw)
                buf = build_excel(df_clean, df_removed,
                                  source_name=uploaded.name)
            except Exception as e:
                st.error(f"Error during processing: {e}")
                import traceback; st.code(traceback.format_exc())
                return

        removed_count = len(df_removed)
        kept_count    = len(df_clean)

        # Results summary
        st.success("✅  Done! Download your cleaned file below.")
        r1, r2, r3, r4 = st.columns(4)
        r1.metric("Rows in",    f"{len(df_raw):,}")
        r2.metric("Rows out",   f"{kept_count:,}")
        r3.metric("Removed",    f"{removed_count}",
                  delta=f"-{removed_count}", delta_color="inverse")
        r4.metric("Faculty",    f"{df_clean['Name'].nunique()}")

        # Faculty summary preview
        totals = (df_clean.groupby("Name")["Assignment %"]
                  .sum().reset_index()
                  .rename(columns={"Assignment %": "Total Assign %"})
                  .sort_values("Total Assign %", ascending=False)
                  .reset_index(drop=True))
        totals["Total Assign %"] = totals["Total Assign %"].round(2)

        with st.expander("📊 Faculty Summary (top 20 by workload)"):
            st.dataframe(totals.head(20), use_container_width=True)

        # Download button
        from datetime import datetime
        fname = f"Faculty_Cleaned_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
        st.download_button(
            label="⬇️  Download Cleaned Excel",
            data=buf,
            file_name=fname,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )

        if removed_count > 0:
            with st.expander(f"🗑️ View {removed_count} removed rows"):
                st.dataframe(df_removed.reset_index(drop=True),
                             use_container_width=True)
